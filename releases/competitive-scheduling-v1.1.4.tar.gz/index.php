<?php
# Silence is golden