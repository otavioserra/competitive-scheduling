<div class="calendarShortcode">
    <div class="ui calendar"></div>
</div>