

<?php

/*
 * Send HTML Emails with inline images
 * 
 * 

// Usage

// Set mail parameters
$to = 'test@example.com';
$subject = 'Inline Img';
$body = '<h1>Image:</h1> <img src="cid:my_img_cid"/>';
$headers = "";
$my_attachments = [
    [
        "cid" => "my_img_cid", // used in email body
        "path" => plugin_dir_path(__FILE__) . '/my_img.png',
    ],
];

$custom_mailer = new Custom_Mailer();
$custom_mailer->send($to, $subject, $body, $headers, $my_attachments);
 */

if( ! class_exists( 'Custom_Mailer' ) ){
    class Custom_Mailer
    {
        public $email_attachments = [];

        public function send( $to, $subject, $body, $headers = '', $attachments = [] ){
            if( CS_EMAIL_ACTIVE ){
                /* Used by "phpmailer_init" hook to add attachments directly to PHPMailer  */
                $this->email_attachments = $attachments;

                /* Setup Before send email */
                add_action('phpmailer_init', [$this, 'add_attachments_to_php_mailer']);
                add_filter('wp_mail_content_type', [$this, 'set_content_type']);
                add_filter('wp_mail_from', [$this, 'set_wp_mail_from']);
                add_filter('wp_mail_from_name', [$this, 'wp_mail_from_name']);
                
                /* Send Email */
                $is_sent = wp_mail($to, $subject, $body, $headers);
                
                /* Cleanup after send email */
                $this->email_attachments = [];
                remove_action('phpmailer_init', [$this, 'add_attachments_to_php_mailer']);
                remove_filter('wp_mail_content_type', [$this, 'set_content_type']);
                remove_filter('wp_mail_from', [$this, 'set_wp_mail_from']);
                remove_filter('wp_mail_from_name', [$this, 'wp_mail_from_name']);

                return $is_sent;
            } else {
                return false;
            }
        }

        public function add_attachments_to_php_mailer( & $phpmailer ){
            $phpmailer->SMTPKeepAlive=true;
            
            /* Sendgrid */
            if( defined( 'SENDGRID_PASSWORD' ) ){
                $phpmailer->IsSMTP();
                $phpmailer->Host="smtp.sendgrid.net";
                $phpmailer->Port = 587;
                $phpmailer->SMTPAuth = true;
                $phpmailer->SMTPSecure = 'tls';
                $phpmailer->Username="apikey";
                $phpmailer->Password = SENDGRID_PASSWORD;   /* api key from sendgrid */
            }

            /* Add attachments to mail */
            foreach( $this->email_attachments as $attachment ){
                if( file_exists( $attachment['path'] ) ){
                    $phpmailer->AddEmbeddedImage( $attachment['path'], $attachment['cid'] );
                }
            }
        }

        public function set_content_type(){
            return "text/html";
        }
        
        public function set_wp_mail_from( $mail ){
            //Make sure the email is from the same domain
            //as your website to avoid being marked as spam.
            return strip_tags( get_option( 'admin_email' ) );
        }

        public function wp_mail_from_name( $name ){
            return get_bloginfo( 'name' );
        }
    }
}